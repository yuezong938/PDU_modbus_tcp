from flask import Flask, render_template, request, redirect, url_for
import modbus_tk.defines as pdu
import modbus_tk.modbus_tcp as modbus_tcp


sever = modbus_tcp.TcpMaster('192.168.1.131', 20105)
sever.set_timeout(5.0)
app = Flask(__name__)

# OneOpen:257  OneClose:256
# TwoOpen:513  TwoClose:512
# ThreeOpen:769  ThreeClose:768
# FourOpen:1025  FourClose:1024
# FiveOpen:1281  FiveClose:1280
# SixOpen:1537  SixClose:1536
# SevenOpen:1793  SevenClose:1792
# EightOpen:2049  EightClose:2048
def switchStatus(outputValue):
    sever.execute(241, pdu.WRITE_SINGLE_REGISTER, 170, output_value=outputValue)


def ReadPDU(deviceid, adress, length):
   return sever.execute(deviceid, pdu.READ_HOLDING_REGISTERS, adress, length)


@app.route('/')
def main():
    status = "{:08b}".format(ReadPDU(241, 157, 1)[0])
    socket_list = [int(i) for element in status for i in element]
    return render_template('index.html', socket_list=socket_list)


@app.route('/', methods=['post'])
def PDUswitch():
    switch = int(request.form['switch_num'])
    switch_num = (switch // 10) % 10
    switch_action = switch % 10
    if switch_num == 0:
        output_value = 256 if switch_action == 1 else 257
        switchStatus(output_value)
    elif switch_num == 1:
        output_value = 512 if switch_action == 1 else 513
        switchStatus(output_value)
    elif switch_num == 2:
        output_value = 768 if switch_action == 1 else 769
        switchStatus(output_value)
    elif switch_num == 3:
        output_value = 1024 if switch_action == 1 else 1025
        switchStatus(output_value)
    elif switch_num == 4:
        output_value = 1280 if switch_action == 1 else 1281
        switchStatus(output_value)
    elif switch_num == 5:
        output_value = 1536 if switch_action == 1 else 1537
        switchStatus(output_value)
    elif switch_num == 6:
        output_value = 1792 if switch_action == 1 else 1793
        switchStatus(output_value)
    elif switch_num == 7:
        output_value = 2048 if switch_action == 1 else 2049
        switchStatus(output_value)
    return redirect(url_for('main'))


if __name__ == '__main__':
   app.run(host='0.0.0.0', port=8010, debug=True)

